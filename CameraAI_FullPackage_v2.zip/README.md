Camera AI App - Full GitHub-ready package (v2)
